Image A:
- full sphere
- partial sphere
- triangle
- anti aliasing
- diffuse
- specular
- refractive
- solid
- parametric

Image B:
- instance
- scaling
- translation

Image C:
- indirect lighting only
- the light is behind the triangle and reflected off the circle to illuminate the triangle



Student Choice:
- Explanation image showing how the eye rays, film, and depth map form right triangles.
- Explanation text explaining how things are done and how the math is derived that is used in the code.