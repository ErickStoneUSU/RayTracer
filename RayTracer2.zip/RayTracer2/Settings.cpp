#pragma once
const int MAX_VAL = 60000;
const int ZDIM = 1;
const int DIM = 17;
const int XDIM = 289;
const int YDIM = 289;
const float eyeDistance = 2.0f;
const float eye2Dist = -eyeDistance * eyeDistance;